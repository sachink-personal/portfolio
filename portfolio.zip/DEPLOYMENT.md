# PythonAnywhere Deployment Guide

This guide shows how to deploy your Quantitative Portfolio Manager on PythonAnywhere.

---

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [GitHub Setup (Optional but Recommended)](#github-setup-recommended)
3. [PythonAnywhere Setup](#pythonanywhere-setup)
4. [Environment Variables](#environment-variables)
5. [Installing Dependencies](#installing-dependencies)
6. [Setting Up the Web App](#setting-up-the-web-app)
7. [Configuring Cron Jobs (Scheduler)](#configuring-cron-jobs-scheduler)
8. [Testing the Deployment](#testing-the-deployment)

---

## Prerequisites

- PythonAnywhere account (free tier works fine)
- Google Cloud Project with Sheets API enabled
- Gmail App Password for email notifications

---

## GitHub Setup (Recommended)

If you don't have a GitHub repo yet:

```bash
# Initialize git
git init

# Add files
git add .
git commit -m "Initial commit for PythonAnywhere deployment"

# Create a new repository on GitHub
# Then run:
git remote add origin https://github.com/YOUR_USERNAME/portfolio_g.git
git push -u origin main
```

---

## PythonAnywhere Setup

### Step 1: Create Account
Go to [https://www.pythonanywhere.com/](https://www.pythonanywhere.com/) and sign up for a free account.

### Step 2: Add Web App
1. Log in to PythonAnywhere dashboard
2. Click on "Web" in the top navigation
3. Click "Add a new web app"
4. Select:
   - **Python version**: 3.11
   - **Source code location**: Your home directory (e.g., `/home/yourusername/portfolio_g`)
5. Click "Next" then "Finish"

### Step 3: Update Code

**Option A - Upload via File Editor (Easier):**
1. Click "Files" in top navigation
2. Navigate to your home directory (e.g., `/home/yourusername/`)
3. Create new directory `portfolio_g`
4. Upload all your files using the file browser

**Option B - Clone from GitHub:**
1. Click "Consoles" in top navigation
2. Open a Bash console
3. Run:
```bash
cd ~
git clone https://github.com/YOUR_USERNAME/portfolio_g.git portfolio_g
cd portfolio_g
```

---

## Environment Variables

PythonAnywhere uses `.env` file for environment variables. Create it:

### Method 1: Using File Editor
1. In PythonAnywhere dashboard, click "Files"
2. Navigate to your `portfolio_g` directory
3. Create new file named `.env`
4. Add your credentials (copy from `.env.example`):

```
GOOGLE_SHEET_ID=your_actual_google_sheet_id
EMAIL_SENDER=you@gmail.com
EMAIL_PASSWORD=your_16_char_app_password
```

**Important:** Never commit `.env` to GitHub!

### Method 2: Using Bash Console
```bash
cd ~
cd portfolio_g
echo "GOOGLE_SHEET_ID=your_sheet_id" > .env
echo "EMAIL_SENDER=you@gmail.com" >> .env
echo "EMAIL_PASSWORD=your_app_password" >> .env
```

---

## Installing Dependencies

### Using Bash Console

Open a Bash console and run:

```bash
cd ~
cd portfolio_g

# Create virtual environment (optional but recommended)
python3.11 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

### Verify Installation

```bash
python3.11 -c "import streamlit; import pandas; print('All imports OK')"
```

---

## Setting Up the Web App

### Configure WSGI File

1. Go back to PythonAnywhere dashboard
2. Click "Web" tab
3. Find your web app and click "Edit configuration file"
4. Replace the entire content with:

```python
import sys

# Add your project directory to the Python path
project_home = '/home/YOUR_USERNAME/portfolio_g'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Import Streamlit app
from streamlit.web import cli as stcli

def application(environ, start_response):
    # Set up environment for your app
    environ['SCRIPT_NAME'] = '/app'
    
    # Run Streamlit
    sys.argv = [
        'streamlit',
        'run', 
        '/home/YOUR_USERNAME/portfolio_g/app.py',
        '--server.port', str(environ['PORT']),
        '--server.enableCORS', 'false',
        '--browser.gatherUsageStats', 'false'
    ]
    
    return stcli.main()(environ, start_response)
```

**Important:** Replace `YOUR_USERNAME` with your actual PythonAnywhere username!

### Alternative: Using Procfile (Easier)

PythonAnywhere also supports Procfile-based deployments:

```bash
cd ~
cd portfolio_g

# Create WSGI file
cat > wsgi.py << 'EOF'
from streamlit.web import cli as stcli
import sys

sys.argv = [
    'streamlit',
    'run',
    '/home/YOUR_USERNAME/portfolio_g/app.py',
    '--server.port=5000',
    '--server.enableCORS=false'
]

stcli.main()
EOF
```

### Configure Static Files (Optional)

1. In the Web tab, scroll down to "Static files"
2. Add:
   - URL: `/static/`
   - Directory: `/home/YOUR_USERNAME/portfolio_g/static/` (create this directory)

---

## Configuring Cron Jobs (Scheduler)

PythonAnywhere allows you to run scheduled tasks using cron.

### Step 1: Configure Scheduled Tasks
1. Click "Tasks" in top navigation
2. Add your cron jobs:

| Time | Command | Notes |
|------|---------|-------|
| Mon-Fri 8:00 AM | `cd /home/YOUR_USERNAME/portfolio_g && python main.py --daily` | Daily digest |
| Sat 9:00 AM | `cd /home/YOUR_USERNAME/portfolio_g && python main.py --weekly` | Weekly analysis |
| 1st Sat 9:00 AM | `cd /home/YOUR_USERNAME/portfolio_g && python main.py --monthly` | Monthly rebalance |

### Step 2: Create Cron Jobs

Click "Add a new scheduled task" and set:

**Daily Job (Mon-Fri 8:00 AM):**
```bash
0 8 * * 1-5 cd /home/YOUR_USERNAME/portfolio_g && python main.py --daily >> /home/YOUR_USERNAME/portfolio_g/daily.log 2>&1
```

**Weekly Job (Sat 9:00 AM):**
```bash
0 9 * * SAT cd /home/YOUR_USERNAME/portfolio_g && python main.py --weekly >> /home/YOUR_USERNAME/portfolio_g/weekly.log 2>&1
```

**Monthly Job (1st Sat 9:00 AM):**
```bash
0 9 1-7 * SAT cd /home/YOUR_USERNAME/portfolio_g && python main.py --monthly >> /home/YOUR_USERNAME/portfolio_g/monthly.log 2>&1
```

### Step 3: Initialize Google Sheets (First Time)

Open a Bash console and run:
```bash
cd ~
cd portfolio_g
python main.py --init
```

This creates the required tabs in your Google Sheet.

### Step 4: Test Email Notifications
```bash
python main.py --test
```

Check your inbox for test emails.

---

## Testing the Deployment

### Test 1: Check Web App
1. Go to PythonAnywhere "Web" tab
2. Click on your domain (e.g., `yourusername.pythonanywhere.com`)
3. Verify the Streamlit app loads

### Test 2: Check Cron Jobs
1. Go to "Tasks" tab
2. Verify all cron jobs are listed
3. Check the log files for any errors

### Test 3: Verify Data
1. Open your Streamlit app
2. Check if holdings load from Google Sheet
3. Verify portfolio value and metrics display

---

## Troubleshooting

### Common Issues

**Issue: "Module not found" error**
```bash
# Install missing modules
pip install module_name
```

**Issue: Web app not loading**
1. Check WSGI file path
2. Restart your web app from Web tab

**Issue: Email not sending**
1. Verify `.env` file exists
2. Check Gmail App Password is correct
3. Enable "Less secure app access" if needed

**Issue: Google Sheets not connecting**
1. Verify `credentials.json` is in correct location
2. Check `GOOGLE_SHEET_ID` is correct
3. Verify service account has editor access to sheet

---

## Free Data Scraping (Future Enhancements)

Once deployed, you can add data scraping from free sites:

### Add yfinance (Already in requirements.txt)
```python
# Already available, no setup needed
import yfinance as yf
```

### Add NSE India API (May need proxy rotation)
```python
import requests

headers = {
    "User-Agent": "Mozilla/5.0...",
}

response = requests.get("https://www.nseindia.com/api/market-data-indices", headers=headers)
```

### Add Tickertape CSV Download
```python
import urllib.request

url = "https://tickertape.in/..."
urllib.request.urlretrieve(url, "downloads/tickertape.csv")
```

---

## Costs

PythonAnywhere Free Tier includes:
- ✅ 1 web app
- ✅ 512MB RAM
- ✅ Cron jobs (unlimited)
- ✅ Bash console
- ❌ 24/7 uptime (app sleeps after inactivity)

Your app will sleep after 15 minutes of inactivity. To keep it awake:
- Set up a free uptime monitoring service (UptimeRobot, Healthchecks.io)
- Or upgrade to paid tier for 24/7 uptime

---

## Quick Checklist

Before going live, verify:
- [ ] `.env` file created with credentials
- [ ] `requirements.txt` in root directory
- [ ] All dependencies installed
- [ ] Google Sheet initialized (`python main.py --init`)
- [ ] Email test passed (`python main.py --test`)
- [ ] Cron jobs configured
- [ ] Web app deployed and accessible

---

## Next Steps

After deployment:
1. Monitor daily emails for portfolio updates
2. Set up uptime monitoring to keep app awake
3. Consider adding scraping for additional data sources
4. Explore paid tier if you need 24/7 uptime

---

**Need Help?**
Check PythonAnywhere documentation: [https://help.pythonanywhere.com/](https://help.pythonanywhere.com/)